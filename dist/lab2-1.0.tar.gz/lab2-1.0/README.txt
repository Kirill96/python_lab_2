Description
===========

The second lab of Python